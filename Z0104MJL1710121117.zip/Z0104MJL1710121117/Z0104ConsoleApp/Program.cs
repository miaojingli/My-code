﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Z0104ConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            string className = args[0];
            Common.ShowInfo($"{className}\n");
            var a = Type.GetType(className);           
            if (a == null)
            {
                Common.ShowWarn("无此例子或该例子尚未实现。");
            }
            else
            {
                Assembly assembly = Assembly.GetExecutingAssembly();
                assembly.CreateInstance(className);
            }                                                        
            Common.WaitKey();
        }
    }
}
