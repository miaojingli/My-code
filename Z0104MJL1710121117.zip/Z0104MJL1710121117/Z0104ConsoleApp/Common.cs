﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Z0104ConsoleApp
{
    class Common
    {
        public static void ShowInfo(string info, bool isWriteLine = true)
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            if (isWriteLine)
            {
                Console.WriteLine(info);
            }
            else
            {
                Console.Write(info);
            }
            Console.ForegroundColor = ConsoleColor.White;
        }
        public static void ShowWarn(string info)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("警告：" + info);
            Console.ForegroundColor = ConsoleColor.White;
        }
        public static void WaitKey()
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine();
            Console.Write("按任意键继续...");
            Console.ReadKey();
            Console.ForegroundColor = ConsoleColor.White;
        }
    }
}
