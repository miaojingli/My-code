﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Z0104ConsoleApp.XT
{
    class XT0301
    {
        class A
        {
            public A()
            {
                Console.WriteLine("XT0301");
            }
            public A(string a)
            {
                Console.WriteLine(a);
            }
        }
        public XT0301()
        {
            A a = new A();
            A a1 = new A("This is string");
            A[] a2 = new A[5];
        }
        
    }
}
