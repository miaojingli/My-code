﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Z0104ConsoleApp.XT
{
    class XT0302
    {
        class A
        {
            public A()
            {
                Console.WriteLine("A");
            }
        }
        class B
        {
            public B()
            {
                Console.WriteLine("B");
            }
        }
        class C1 : A
        {
            B b = new B();
        }
        class C2 : A
        {
            B b = new B();
            public C2()
            {
                Console.WriteLine("C");
            }

        }
        public XT0302()
        {
            C1 c1 = new C1();
            C2 c2 = new C2();
        }
    }
}
