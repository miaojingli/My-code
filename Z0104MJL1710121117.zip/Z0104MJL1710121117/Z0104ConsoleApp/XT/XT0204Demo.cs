﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Z0104ConsoleApp.XT
{
    class XT0204Demo
    {
        public XT0204Demo()
        {
            //用for语句实现
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("用for语句实现：");
            Console.ForegroundColor = ConsoleColor.White;
            for (int i = 1; i <= 5; i++)
            {
                Console.WriteLine("{0}的平方值为{1}", i, i * i);
            }

            //用while语句实现
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("\n用while语句实现：");
            Console.ForegroundColor = ConsoleColor.White;
            int j = 0;
            while (j++ < 5)
            {
                Console.WriteLine("{0}的平方值为{1}", j, j * j);
            }

            //用do-while语句实现
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("\n用do-while语句实现：");
            Console.ForegroundColor = ConsoleColor.White;
            int k = 1;
            do
            {
                Console.WriteLine("{0}的平方值为{1}", k, k * k);
            } while (k++ < 5);
        }
    }
}
