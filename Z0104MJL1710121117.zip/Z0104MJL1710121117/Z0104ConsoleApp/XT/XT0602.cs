﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Z0104ConsoleApp.XT
{
    
    class XT0602
    {
        string path;
        public XT0602()
        {
            try
            {
                Console.Write("请输入要删除的文件的详细地址:");
                path = Console.ReadLine();
                File.Delete(path);
            }catch(Exception e)
            {

            }
            
        }
    }
}
