﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Z0104ConsoleApp.XT
{
    class XT0103Demo
    {
        public XT0103Demo()
        {
            Console.WriteLine("{0}--{0:p}good", 12.34F);
            Console.WriteLine("{0}--{0:####}good", 0);
            Console.WriteLine("{0}--{0:00000}good", 456);
        }
    }
}
