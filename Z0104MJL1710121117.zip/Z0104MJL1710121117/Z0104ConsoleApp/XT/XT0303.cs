﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Z0104ConsoleApp.XT
{
    class XT0303
    {

        class D
        {
            public void MyMethod(int a)
            {
                a += 10;
                Console.WriteLine(a);
            }
        }
        class E : D
        {
            public void MyMethod(int a)
            {
                a += 50;
                Console.WriteLine(a);
            }
        }
        public XT0303()
        {
            D d = new D();
            d.MyMethod(10);
            E e = new E();
            e.MyMethod(10);            
        }
    }
}
