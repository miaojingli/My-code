﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Z0104ConsoleApp.XT
{
    class XT0203
    {
        public XT0203()
        {
            p:
            Console.Write("请输入一个长度大于3的字符串:");
            var v = Console.ReadLine();
            if (v.Length < 3)
            {
                Console.WriteLine("输入字符少于3个，请重新输入。");
                goto p;
            }
            int x = v.IndexOf('a');
            string v1 = v.Insert(3, "hello");
            string v2 = v1.Replace("hello", "me");
            string[] b = v2.Split('m');
            Console.Write("字符串的长度：");
            Console.WriteLine(v.Length);
            Console.Write("第一个出现字母a的位置：");
            Console.WriteLine(x);
            Console.Write("插入hello后的新字符串：");
            Console.WriteLine(v1);
            Console.Write("替换hello后的新字符串：");
            Console.WriteLine(v2);
            Console.Write("分离后的字符串：");   
            foreach (var v3 in b)   
            {
                Console.Write(v3);
                Console.Write(" ");
            }
        }
    }
}
