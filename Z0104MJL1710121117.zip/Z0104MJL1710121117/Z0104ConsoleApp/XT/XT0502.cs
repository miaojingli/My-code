﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Z0104ConsoleApp.XT
{
    class XT0502
    {
        StringBuilder sb = new StringBuilder();
        public  XT0502()
        {
            var s1 = new SortedList<int, string>
            {
                { 20, "张三" },
                { 23, "李四" },
                { 10, "王二" },
                { 19, "孙六" },
                { 220, "赵七" }
            };
            int last = s1.Count - 1;
            for (int i = last; i >= 0; i--)
            {
                Console.WriteLine("{0}\t {1}\t", s1.Keys[i], s1.Values[i]);
            }

        }
        
}
}
