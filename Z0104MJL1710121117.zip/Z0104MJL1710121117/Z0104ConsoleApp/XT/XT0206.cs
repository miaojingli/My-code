﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Z0104ConsoleApp.XT
{
    class XT0206
    {
        int i = 0;
        public XT0206()
        {
            while (i!=1)
            {
                while (i == 0)
                {
                    Console.Write("请输入一个整数:");
                    var v = Console.ReadLine();
                    int n = int.Parse(v);
                    if (n > 0)
                    {
                        for (int i = 1; i <=n; i++)
                        {
                            Console.Write(i);
                            Console.Write(' ');                            
                        }
                        i = 1;
                        break;
                    }
                    else if (n < 0)
                    {
                        i = 0;
                        break;
                    }
                   
                }
            }
        }
    }
}
