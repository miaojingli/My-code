﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Z0104ConsoleApp.XT
{
    class XT0208Demo
    {
        public XT0208Demo()
        {
            int n = 50;
            double x = 3;
            double s = 0;
            double a = 1;
            for (int i = 1; i <= n; i++)
            {
                a *= i;
                s += Math.Pow(-1, i + 1) * Math.Pow(x, i) / a;
            }
            Console.WriteLine("n={0},s={1:0.00000000}", n, s);
        }
    }
}
