﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Z0104ConsoleApp.ShangJiLianXi
{
    class A0203
    {
        int d;
        public A0203()
        {
            p:
            Console.Write("请输入一个大于100的整数:");
            int x=int.Parse(Console.ReadLine());
            string a = x.ToString();
            string[] v = new string[100];
            string b ;
            int sum1 = 0;
            int sum2 =0;
            Console.WriteLine("该整数共有{0}位", a.Length);
            Console.Write("实现思路1:每一位的值为");
            for (int i = 0; i < a.Length; i++)
            {
                v[i] = a.Substring(i, 1);
                sum1 += int.Parse(v[i]);
                Console.Write(v[i]);
                if (i < a.Length - 1)
                {
                    Console.Write('、');
                }
            }
            Console.Write("，这些位之和：{0}", sum1);
            int[] n = new int[100];
            for (int i = 0; i < a.Length; i++)
            {
                n[i] = x % 10;
                sum2 += n[i];
                x = x / 10;
            }
            Console.WriteLine("");
            Console.Write("实现思路2:每一位的值为");
            for (int i = a.Length-1; i >=0; i--)
            {
                Console.Write(n[i]);
                if (i > 0)
                { 
                Console.Write("、");
                }
            }
            Console.WriteLine("，这些位之和：{0}", sum2);
            Console.WriteLine("按回车键退出，其他键继续！");
            if (Console.ReadKey(true).Key == ConsoleKey.Enter)
            {
                
            }
            else
            {
                goto p;
            }

        }
    }
}
