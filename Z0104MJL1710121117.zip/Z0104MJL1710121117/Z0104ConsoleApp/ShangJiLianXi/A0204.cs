﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Z0104ConsoleApp.ShangJiLianXi
{
    class A0204
    {
        public A0204()
        {
            P:
            a:
            Console.Write("请输入5个用逗号分隔的整数:");
            string a = Console.ReadLine();
            string[] v = a.Split(',','，');
            int[] b = new int[v.Length];
            try { 
            for (int i = 0; i < v.Length; i++)
            {
                b[i] = int.Parse(v[i]);
            }
            }
            catch
            {
                Console.WriteLine("输入非法，请重新输入");
                goto a;
            }
            Console.Write("正序：");
            for (int i = 0; i < v.Length; i++)
            {
                Console.Write(b[i]);
                if (i < v.Length - 1)
                {
                    Console.Write(",");
                }
            }
            Console.WriteLine("");
            Array.Reverse(b);
            Console.Write("逆序：");
            for (int i = 0; i < v.Length; i++)
            {
                Console.Write(b[i]);
                if (i < v.Length - 1)
                {
                    Console.Write(",");
                }
            }
            Console.WriteLine("");
            Console.Write("平均值：");
            Console.Write(b.Average());
            Console.WriteLine("");
            Console.Write("最大值：");
            Console.Write(b.Max());
            Console.WriteLine();
            Console.WriteLine("按回车键退出，其他键继续！");
            if (Console.ReadKey(true).Key == ConsoleKey.Enter)
            {

            }
            else
            {
                goto P;
            }
        }
    }
}
