﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace Z0104WpfApp.Demos.DrawDemo.Simple
{
    public class DrawRectangle : DrawObject
    {
        public Rect Rect { get; set; }
        public DrawRectangle(Image image) : base(image) { }
        public override void Draw()
        {
            RectangleGeometry rg = new RectangleGeometry(Rect);
            gd.Geometry = rg;
            ImageSource source = new DrawingImage(gd);
            Image.Source = source;
        }
    }
}
