﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace Z0104WpfApp.Demos.DrawDemo.Simple
{
    public class DrawEllipse : DrawObject
    {
        public Point Center { get; set; }
        public double RadiusX { get; set; }
        public double RadiusY { get; set; }
        public DrawEllipse(Image image) : base(image) { }
        public override void Draw()
        {
            var g = new EllipseGeometry
            {
                Center = Center,
                RadiusX = RadiusX,
                RadiusY = RadiusY
            };
            gd.Geometry = g;
            Image.Source = new DrawingImage(gd);
        }
    }
}
