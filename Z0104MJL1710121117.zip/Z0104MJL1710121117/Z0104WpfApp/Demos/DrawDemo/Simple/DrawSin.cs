﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace Z0104WpfApp.Demos.DrawDemo.Simple
{
    public class DrawSin : DrawLine
    {
        public DrawSin(Image image) : base(image)
        {
            pen.Brush = Brushes.Red;
        }

        public override void Draw()
        {
            int a = 120;
            double w = Image.Width, h = Image.Height;
            double w1 = (a - w) / 2, h1 = (a - h) / 2;

            PointCollection points = new PointCollection();
            PathGeometry pathGeometry = new PathGeometry();

            //横坐标
            var path1 = Geometry.Parse("M-385,0 L385,0 375,5 M385,0 L375,-5");
            pathGeometry.AddGeometry(path1);

            //纵坐标
            var path2 = Geometry.Parse("M0,-100 L0,105 M0,-105 L-5,-95 M0,-105 L5,-95");
            pathGeometry.AddGeometry(path2);

            //正弦曲线
            for (int i = -360; i <= 360; i++)
            {
                Point p = new Point(i, -a * Math.Sin(i * Math.PI / 180.0));
                points.Add(p);
            }
            int len = points.Count;
            for (int i = 0; i < points.Count - 1; i++)
            {
                LineGeometry line = new LineGeometry
                {
                    StartPoint = points[i],
                    EndPoint = points[i + 1]
                };
                pathGeometry.AddGeometry(line);
            }
            gd.Geometry = pathGeometry;
            gd.Pen = pen;
            Image.Source = new DrawingImage(gd);
        }
    }
}
