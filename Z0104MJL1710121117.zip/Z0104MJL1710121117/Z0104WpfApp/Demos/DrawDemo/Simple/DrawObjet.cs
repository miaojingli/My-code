﻿using System.Windows.Controls;
using System.Windows.Media;
namespace Z0104WpfApp.Demos.DrawDemo.Simple
{
    public abstract class DrawObject
    {
        protected Pen pen = new Pen(Brushes.Blue, 2.0);
        protected GeometryDrawing gd = new GeometryDrawing();
        public Image Image { get; set; }
        public DrawObject(Image image)
        {
            gd.Pen = pen;
            Image = image;
        }
        public abstract void Draw();
    }
}
