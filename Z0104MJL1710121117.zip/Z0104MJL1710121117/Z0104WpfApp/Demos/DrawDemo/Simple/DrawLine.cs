﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
namespace Z0104WpfApp.Demos.DrawDemo.Simple
{
    public class DrawLine : DrawObject
    {
        public Point StartPoint { get; set; }
        public Point EndPoint { get; set; }
        public double LineWidth { get; set; } = 1.0;

        public DrawLine(Image image) : base(image) { }

        public override void Draw()
        {
            pen.Thickness = LineWidth;
            LineGeometry geometry = new LineGeometry
            {
                StartPoint = StartPoint,
                EndPoint = EndPoint
            };
            gd.Geometry = geometry;
            gd.Pen = pen;
            Image.Source = new DrawingImage(gd);
        }
    }
}
