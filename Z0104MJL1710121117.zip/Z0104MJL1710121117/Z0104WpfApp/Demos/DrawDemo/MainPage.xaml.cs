﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Z0104WpfApp.Demos.DrawDemo
{
    /// <summary>
    /// MainPage.xaml 的交互逻辑
    /// </summary>
    public partial class MainPage : Page
    {
        public MainPage()
        {
            InitializeComponent();

            var v = new SimpleDrawDemo(myImage);
            btnLine.Click += delegate {
                v.Draws[0].Draw();
                image1.Source = v.Draws[0].Image.Source;
            };
            btnRectangle.Click += delegate {
                v.Draws[1].Draw();
                image2.Source = v.Draws[1].Image.Source;
            };
            btnCircle.Click += delegate {
                v.Draws[2].Draw();
                image3.Source = v.Draws[2].Image.Source;
            };
            btnEllipse.Click += delegate {
                v.Draws[3].Draw();
                image4.Source = v.Draws[3].Image.Source;
            };
            btnSin.Click += delegate {
                v.Draws[4].Draw();
                image5.Source = v.Draws[4].Image.Source;
            };
            btnClear.Click += delegate {
                myImage.Source = null;
                image1.Source = null;
                image2.Source = null;
                image3.Source = null;
                image4.Source = null;
                image5.Source = null;
            };
        }
    }
}
