﻿using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using Z0104WpfApp.Demos.DrawDemo.Simple;

namespace Z0104WpfApp.Demos.DrawDemo
{
    public class SimpleDrawDemo
    {
        public List<DrawObject> Draws { get; } = new List<DrawObject>();
        public SimpleDrawDemo(Image image)
        {
            double w = image.Width;
            double h = image.Height;
            //直线
            var a = 15.0;
            var line = new DrawLine(image)
            {
                StartPoint = new Point(a, a),
                EndPoint = new Point(w - a, h - a)
            };
            Draws.Add(line);
            //矩形
            var rectangle = new DrawRectangle(image)
            {
                Rect = new Rect(0, 0, w, h)
            };
            Draws.Add(rectangle);
            //圆
            var circle = new DrawEllipse(image)
            {
                Center = new Point(w / 2, h / 2),
                RadiusX = w / 2,
                RadiusY = w / 2
            };
            Draws.Add(circle);
            //椭圆
            var ellipse = new DrawEllipse(image)
            {
                Center = new Point(w / 2, h / 2),
                RadiusX = (w - 100) / 2,
                RadiusY = h / 4
            };
            Draws.Add(ellipse);
            //正弦曲线
            var sin = new DrawSin(image);
            Draws.Add(sin);
        }
    }
}
