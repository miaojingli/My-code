﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Z0104WpfApp.ShangJiLianXi
{
    /// <summary>
    /// A0201.xaml 的交互逻辑
    /// </summary>
    public partial class A0201 : Page
    {
        int i;
        public A0201()
        {
            InitializeComponent();
        }
        private void passbox1_PasswordChanged(object sender, RoutedEventArgs e)
        {

            if (C1.IsChecked == true)
            { 
                T2.Text = P1.Password;
            }
            else
            {
               T2.Clear();
            }
        }

        private void check_Checked(object sender, RoutedEventArgs e)
        {
            if (C1.IsChecked == true)
            {
                T2.Text = P1.Password;
            }
            else
            {
                T2.Clear();
            }
        }

        private void C1_Checked(object sender, RoutedEventArgs e)
        {

        }
    }
}
