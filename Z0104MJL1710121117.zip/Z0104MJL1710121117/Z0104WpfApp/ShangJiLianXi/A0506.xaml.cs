﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Z0104WpfApp.ShangJiLianXi
{
    /// <summary>
    /// A0506.xaml 的交互逻辑
    /// </summary>
    public partial class A0506 : Page
    {
        private byte[] a = new byte[8];
        private System.Timers.Timer timers;
        public A0506()
        {
            InitializeComponent();
            timers = new System.Timers.Timer(1000);
            timers.Elapsed += Timers_Elapsed;
        }

        private void Timers_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            this.Dispatcher.InvokeAsync(action);
        }

        private void action()
        {
            int b = int.Parse(textblock.Text);
            b = b - 1;
            if (b == -1)
            {
                b = 0;
                timers.Stop();
                MessageBox.Show("过关失败，请继续努力！");
            }
            textblock.Text = b.ToString();
        }

        private void btn1_Click(object sender, RoutedEventArgs e)
        {
            textblock.Text = "25";
            timers.Start();
            Random r = new Random();
            r.NextBytes(a);
            for (int i = 0; i < 8; i++)
            {
                int j;
                if (a[i] > 100)
                {
                    j = a[i] / 100;
                    a[i] = (byte)j;
                }
            }
            textbox1.Text = a[0].ToString();
            textbox2.Text = a[1].ToString();
            textbox3.Text = a[2].ToString();
            textbox4.Text = a[3].ToString();
            textbox5.Text = a[4].ToString();
            textbox6.Text = a[5].ToString();
            textbox7.Text = a[6].ToString();
            textbox8.Text = a[7].ToString();
            textbox9.Clear();
            textbox10.Clear();
            textbox11.Clear();
            textbox12.Clear();

        }

        private void btn2_Click(object sender, RoutedEventArgs e)
        {
            int t1, t2, t3, t4;
            try
            {
                t1 = int.Parse(textbox9.Text);
                t2 = int.Parse(textbox10.Text);
                t3 = int.Parse(textbox11.Text);
                t4 = int.Parse(textbox12.Text);
                if (a[0] + a[4] == t1 && a[1] - a[5] == t2 && a[2] * a[6] == t3 && a[3] / a[7] == t4)
                {
                    MessageBox.Show("恭喜，过关成功。");
                }
                else if (textblock.Text == "0")
                {
                    MessageBox.Show("过关失败，请继续努力！");
                }
            }
            catch
            {
                MessageBox.Show("过关失败，请继续努力！");
            }

            

        }
    }
}
