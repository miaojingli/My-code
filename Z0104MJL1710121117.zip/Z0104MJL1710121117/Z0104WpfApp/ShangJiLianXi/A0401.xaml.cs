﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Z0104WpfApp.ShangJiLianXi
{
    /// <summary>
    /// A0401.xaml 的交互逻辑
    /// </summary>
    public partial class A0401 : Page
    {
        private List<Person> p1;
        public A0401() 
        {
            InitializeComponent();
            p1 = new List<Person>
            {
                new Person{name= "张三丰",Age=21,Phone=13037853201 },
                new Person{name= "李四明",Age=18,Phone=13537812345 },
                new Person{name= "赵六方",Age=19,Phone=15228680218 },
                new Person{name= "于五新",Age=20,Phone=15222873156 },
                new Person{name= "李一鸣",Age=24,Phone=15923456789 },
            };
            rb1.Click += Rb1_Click;
            rb2.Click += Rb2_Click;
            rb3.Click += Rb3_Click;
        }

        private void Rb3_Click(object sender, RoutedEventArgs e)
        {
            var q = from p in p1
                    where p.name.StartsWith("李")==true 
                    select p;
            Show(q);
        }

        private void Rb2_Click(object sender, RoutedEventArgs e)
        {
            var q = from p in p1
                    where p.Age > 18 && p.Age < 25
                    select p;
            Show(q);
        }

        private void Rb1_Click(object sender, RoutedEventArgs e)
        {
            var q = from p in p1
                    select p;
            Show(q);
            
        }

        private void Show(IEnumerable<Person> p)
        {
            list1.Items.Clear();
            list1.Items.Add("姓名       年龄       手机号码");
            foreach (var v in p)
            {
                list1.Items.Add(v.Print());
            }
        }
    }
}
