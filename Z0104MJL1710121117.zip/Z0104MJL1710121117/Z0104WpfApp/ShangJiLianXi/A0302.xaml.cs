﻿using System;
using System.Diagnostics;
using System.Windows.Threading;
using System.Windows;
using System.Windows.Controls;

namespace Z0104WpfApp.ShangJiLianXi
{
    /// <summary>
    /// A0302.xaml 的交互逻辑
    /// </summary>
    /// 
    public partial class A0302 : Page
    {
        private DispatcherTimer timer1 = new DispatcherTimer();
        private int min, max;
        private double oldFontSize;
        private double newFontSize;
        private bool isIntRandom = true;      
        public A0302()
        {
            InitializeComponent();
            text.Text = "";
            oldFontSize = text.FontSize;
            newFontSize = oldFontSize * 5;
            timer1.Tick += Timer1_Tick;
            InitParameters();
            SetState(false);
        }
        private void InitParameters()
        {
            int inteval;
            if (int.TryParse(textbox3.Text, out inteval) == false)
            {
                textbox3.Text = "500";
                timer1.Interval = TimeSpan.FromMilliseconds(50);
            }
            else
            {
                timer1.Interval = TimeSpan.FromMilliseconds(inteval);
            }
            if (int.TryParse(textbox1.Text, out min) == false)
            {
                textbox1.Text = "0";
                min = 0;
            }
            if (int.TryParse(textbox2.Text, out max) == false)
            {
                textbox2.Text = "100";
                max = 100;
            }
            if (rb1.IsChecked == true)
            {
                isIntRandom = true;
            }
            else
            {
                isIntRandom = false;
            }
        }
        private void SetState(bool isStarted)
        {
            btn2.IsEnabled = isStarted;
            groupbox1.IsEnabled = !isStarted;
            btn1.IsEnabled = !isStarted;
            if (isStarted)
            {
                text.FontSize = oldFontSize;
            }
            else
            {
                text.FontSize = newFontSize;
            }
        }
        private void Timer1_Tick(object sender, EventArgs e)
        {
            if (isIntRandom)
            {
                int r = A0302.GetIntRandomNumber(min, max);
                text.Text = r.ToString();
            }
            else
            {
                double r = A0302.GetDoubleRandomNumber(min, max);
                text.Text = r.ToString();
            }
        }
        private void btn1_Click(object sender, RoutedEventArgs e)
        {
            InitParameters();
            SetState(true);
            timer1.Start();
        }
        private void btn2_Click(object sender, RoutedEventArgs e)
        {
            SetState(false);
            timer1.Stop();
        }        
    }
}
