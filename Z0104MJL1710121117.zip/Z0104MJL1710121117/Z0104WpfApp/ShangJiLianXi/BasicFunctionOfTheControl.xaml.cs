﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Z0104WpfApp.ShangJiLianXi
{
    /// <summary>
    /// BasicFunctionOfTheControl.xaml 的交互逻辑
    /// </summary>
    public partial class BasicFunctionOfTheControl : Window
    {
        public BasicFunctionOfTheControl()
        {
            InitializeComponent();
        }
        private void btn1_Click(object sender, RoutedEventArgs e)
        {
            text2.Text = text1.Text;
        }
        private void btn2_Click(object sender, RoutedEventArgs e)
        {
            
            if (text2.FontSize < 30)
            {
               text2.FontSize+=2;
            }
            else
            {
                text2.FontSize=30 ;
            }
        }
        
        private void btn3_Click(object sender, RoutedEventArgs e)
        {
            if (text2.FontSize >10)
            {
                text2.FontSize -= 2;
            }
            else
            {
                text2.FontSize = 10;
            }
        }

        private void btn4_Click(object sender, RoutedEventArgs e)
        {
            Random r = new Random();
            byte[] b = new byte[3];
            r.NextBytes(b);
            Color color = Color.FromArgb(255, b[0], b[1], b[2]);
            text2.Foreground = new SolidColorBrush(color);
        }

        
    }
}
