﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Z0104WpfApp.ShangJiLianXi
{
    enum CourseTime { 春季,秋季 };
    class CourseInfo
    {
        public int Counter = 0;
        public string CourseName { get; set; }
        public string BookName { get; set; }
        public double Price { get; set; }
        public CourseTime courseTime;
        public CourseInfo()
        {

            CourseName = BookName = null;
            Price = 0;
            courseTime = CourseTime.春季;
            Counter++;
        }
        public CourseInfo(string course,string book ,CourseTime time,double price)
        {
            CourseName = course;
            BookName = book;
            courseTime = time;
            Price = price;
        }
        public string Print()
        {
            return string.Format("{0,-10}{1,-10}{2,-10}{3,5}",
                CourseName, courseTime, BookName, Price);
        }
    }
}
