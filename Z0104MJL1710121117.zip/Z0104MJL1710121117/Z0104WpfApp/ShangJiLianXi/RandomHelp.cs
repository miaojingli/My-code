﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Z0104WpfApp.ShangJiLianXi
{
    partial class A0302
    {
        private static Random r = new Random();        
        public static int GetIntRandomNumber(int min, int max)
        {
            return r.Next(min, max + 1);
        }      
        public static double GetDoubleRandomNumber(int min, int max)
        {
            double d = max * r.NextDouble();
            if (d < min)
            {
                d += min;
            }
            return Math.Min(d, max);
        }
    }
}

