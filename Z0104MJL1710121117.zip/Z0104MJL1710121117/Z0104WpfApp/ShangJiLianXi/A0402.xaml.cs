﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Z0104WpfApp.ShangJiLianXi
{
    /// <summary>
    /// A0402.xaml 的交互逻辑
    /// </summary>
    public partial class A0402 : Page
    {
        private string path;
        public A0402()
        {
            InitializeComponent();
            button1.Click += Button1_Click;
            button2.Click += Button2_Click;
            button3.Click += Button3_Click;
        }

        private void Button1_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog f = new OpenFileDialog();
            if (f.ShowDialog() == true)
            {
                text2.Text = f.FileName;
            }
        }

        private void Button3_Click(object sender, RoutedEventArgs e)
        {
            try { 
            string s = text1.Text;
            File.WriteAllText(path, s, Encoding.Default);
            text1.Text = "";
            }
            catch (Exception) { }
        }

        private void Button2_Click(object sender, RoutedEventArgs e)
        {
            path = text2.Text;
            if (File.Exists(path))
            {
                string[] s = File.ReadAllLines(path, Encoding.Default);
                text1.Text = string.Join("\r\n", s);
            }

        }
    }
}
