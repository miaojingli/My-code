﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Z0104WpfApp.ShangJiLianXi
{
    /// <summary>
    /// A05010.xaml 的交互逻辑
    /// </summary>
    public partial class A05010 : Page
    {
        public A05010()
        {
            InitializeComponent();
        }

        private void Btn1_Click(object sender, RoutedEventArgs e)
        {
            string tag = (e.Source as Button).Tag.ToString();
            switch (tag)
            {
                case "A05011":
                    {
                        var w = new ShangJiLianXi.A05011();
                        w.ShowDialog();
                        break;
                    }
                default:
                    MessageBox.Show("未找到：" + tag, "出错了");
                    break;

            }
        }
    }
}
