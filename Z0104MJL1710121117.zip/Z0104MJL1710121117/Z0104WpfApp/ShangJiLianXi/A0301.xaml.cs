﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Z0104WpfApp.ShangJiLianXi
{
    /// <summary>
    /// A0301.xaml 的交互逻辑
    /// </summary>
    public partial class A0301 : Page
    {
        public A0301()
        {
            InitializeComponent();
            this.Loaded += A0301_Loaded;
        }

        private void A0301_Loaded(object sender, RoutedEventArgs e)
        {
            lb1.Items.Add(string.Format(
                "{0,-10}{1,-10}{2,-20}{3,2}",
                "课程名", "开设学期", "书名", "定价"));
            var course1=new CourseInfo ()
            {
                CourseName = "数据结构",
                courseTime = CourseTime.春季,
                BookName = "《数据结构》",
                Price = 40
            };
            lb1.Items.Add(course1.Print());
            var course2 = new CourseInfo()
            {
                CourseName = "操作系统",
                courseTime = CourseTime.秋季,
                BookName = "《操作系统》",
                Price = 45
            };
            lb1.Items.Add(course2.Print());
            var course3 = new CourseInfo()
            {
                CourseName = "软件工程",
                courseTime = CourseTime.春季,
                BookName = "《软件工程》",
                Price = 38
            };
            lb1.Items.Add(course3.Print());
        }
    }
}
