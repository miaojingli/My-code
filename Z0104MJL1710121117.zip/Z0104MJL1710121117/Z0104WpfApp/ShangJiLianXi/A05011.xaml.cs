﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Z0104WpfApp.ShangJiLianXi
{
    /// <summary>
    /// A05011.xaml 的交互逻辑
    /// </summary>
    public partial class A05011 : Window
    {
        private int tryCount = 3;
        private System.Timers.Timer timer;  //定时器
        private Boolean isShow;
        private Boolean isPassword;
        public A05011()
        {
            InitializeComponent();
            errorTip2.Visibility =Visibility.Hidden;
            timer = new System.Timers.Timer(200);
            timer.Elapsed += timer_Elapsed;
        }

        private void timer_Elapsed(object sender, ElapsedEventArgs e)
        {
            this.Dispatcher.InvokeAsync(TimerAction);
        }
        private void TimerAction()
        {
            if (isShow == true)
            {
                //if (isUserNameError)
                //{
                //    errorTip1.Visibility = System.Windows.Visibility.Visible;
                //}
                if (!isPassword)
                {
                    errorTip2.Visibility = System.Windows.Visibility.Visible;
                }
                isShow = false;
            }
            else
            {
                //errorTip1.Visibility = System.Windows.Visibility.Hidden;
                errorTip2.Visibility = System.Windows.Visibility.Hidden;
                isShow = true;
            }
        }
        private void Button1_Click(object sender, RoutedEventArgs e)
        {
            if (comboBox.SelectedIndex == 0&&password.Password=="123abc")
            {
                this.Close();
                var w = new A05012();
                w.ShowDialog();
            }
            
            else if (comboBox.SelectedIndex == 1 && password.Password == "abcabc")
            {
                this.Close();
                var w = new A05012();
                w.ShowDialog();

            }
            else
            {
                isPassword = false;
                isShow = true;
                timer.Start();
                tryCount--;
                if (tryCount == 0)
                {
                    App.Current.Shutdown();
                }
                MessageBox.Show("登录失败（还有" + tryCount + "次机会）");
            }
            
        }

        private void Button2_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
