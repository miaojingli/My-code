﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Z0104WpfApp.ShangJiLianXi
{
    class Person
    {
        public string name { get; set; }
        private int age;
        private long phone;
               
        public int Age
        {
            get { return age; }
            set
            {
                if (value >= 15 || value <= 130)
                {
                    age = value;
                }
            }
        }               
        public long Phone
        {
            get { return phone; }
            set
            {
                if (value.ToString().Length == 11)
                {
                    phone = value;
                }
             
            }
        }

        public Person()
        {
            name = "<null>";
            age = 0;
            phone = 0;
        }

        public string Print()
        {         
            return string.Format("{0}\t{1}\t{2}", name, age, phone);
        }
    }

}

