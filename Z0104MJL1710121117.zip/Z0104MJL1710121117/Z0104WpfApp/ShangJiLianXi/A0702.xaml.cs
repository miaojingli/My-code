﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Z0104WpfApp.ShangJiLianXi
{
    /// <summary>
    /// A0702.xaml 的交互逻辑
    /// </summary>
    public partial class A0702 : Page
    {
        public A0702()
        {
            InitializeComponent();
            Loaded += A0702_Loaded;
            using (var c = new MyTestDbEntities())
            {
                List<Student> students = new List<Student>
                {
                new Student
                {
                    学号 = "13001001",
                    姓名 = "张三雨",
                    性别 = "男",
                    出生日期 = DateTime.Parse("1990-5-4"),
                    专业编码 = "01",
                    宿舍号 = "1-202"
                },
                new Student
                {
                    学号 = "13001002",
                    姓名 = "李四平",
                    性别 = "男",
                    出生日期 = DateTime.Parse("1990-6-1"),
                    专业编码 = "01",
                    宿舍号 = "1-202"
                },
                new Student
                {
                    学号 = "13001003",
                    姓名 = "王五生",
                    性别 = "男",
                    出生日期 = DateTime.Parse("1989-7-1"),
                    专业编码 = "03",
                    宿舍号 = "1-202"
                },
                    new Student
                {
                    学号 = "13001004",
                    姓名 = "赵六博",
                    性别 = "男",
                    出生日期 = DateTime.Parse("1989-7-7"),
                    专业编码 = "03",
                    宿舍号 = "1-202"
                },
                    new Student
                {
                    学号 = "13001005",
                    姓名 = "武松燕",
                    性别 = "女",
                    出生日期 = DateTime.Parse("1990-8-1"),
                    专业编码 = "03",
                    宿舍号 = "2-203"
                },
                    new Student
                {
                    学号 = "13001006",
                    姓名 = "刘虎欣",
                    性别 = "女",
                    出生日期 = DateTime.Parse("1990-9-10"),
                    专业编码 = "02",
                    宿舍号 = "2-203"
                }
                };
                c.Student.AddRange(students);
                List<Subject> subjects = new List<Subject>
                {
                new Subject { 编码 = "01", 名称 = "网络工程" },
                new Subject { 编码 = "02", 名称 = "软件工程" },
                new Subject { 编码 = "03", 名称 = "计算机科学与技术" }
                };
                c.Subject.AddRange(subjects);
                List<Dormitory> dormitories = new List<Dormitory>
                {
                new Dormitory { 宿舍号 = "1-202", 人数上限 = 4, 所属院系 = "计算机", 成员数 = 4 },
                new Dormitory { 宿舍号 = "2-203", 人数上限 = 4, 所属院系 = "计算机", 成员数 = 2 }
                };
                c.Dormitory.AddRange(dormitories);
                try
                {
                    c.SaveChanges();
                }
                catch
                {

                }
            }
        }

        private void A0702_Loaded(object sender, RoutedEventArgs e)
        {
            using (var a = new MyTestDbEntities())
            {
                var q = from t1 in a.Student
                        from t2 in a.Subject
                        where t1.专业编码 == t2.编码
                        select new
                        {
                            学号 = t1.学号,
                            姓名 = t1.姓名,
                            性别 = t1.性别,
                            专业 = t2.名称,
                            宿舍 = t1.宿舍号
                        };
                datagrid1.ItemsSource = q.ToList();
                var p = from t3 in a.Dormitory
                        where t3.成员数 < 4
                        select new
                        {
                            宿舍 = t3.宿舍号,
                            学院 = t3.所属院系,
                            成员数 = t3.成员数,
                            床位上限 = t3.人数上限
                        };
                datagrid2.ItemsSource = p.ToList();
            }
        }
    }
}
