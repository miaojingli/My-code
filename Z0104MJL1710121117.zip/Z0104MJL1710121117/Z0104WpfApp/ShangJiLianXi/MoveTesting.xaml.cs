﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Z0104WpfApp.ShangJiLianXi
{
    /// <summary>
    /// MoveTesting.xaml 的交互逻辑
    /// </summary>
    public partial class MoveTesting : Window
    {


        public MoveTesting()
        {
            InitializeComponent();
            btnDown.Interval = btnLeft.Interval = btnRight.Interval = btnUp.Interval;

        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            RepeatButton btn = e.Source as RepeatButton;
            string q = btn.Content.ToString();
            var w = label1.Margin.Top;
            var s = label1.Margin.Bottom;
            var a = label1.Margin.Left;
            var d = label1.Margin.Right;
            var n = 5;
            switch (q)
            {
                case "LEFT":
                    label1.Margin = new Thickness(a - n, w, d, s);
                    break;
                case "RIGHT":
                    label1.Margin = new Thickness(a + n, w, d, s);
                    break;
                case "UP":
                    label1.Margin = new Thickness(a, w - n, d, s);
                    break;
                case "DOWN":
                    label1.Margin = new Thickness(a, w + n, d, s);
                    break;
            }
        }
    }
}
