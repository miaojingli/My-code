﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Z0104WpfApp.ShangJiLianXi
{
    /// <summary>
    /// A0202.xaml 的交互逻辑
    /// </summary>
    public partial class A0202 : Page
    {
        int i;
        double sum = 0;
        public A0202()
        {
            InitializeComponent();
            R1.Click += delegate
            {
                T1.Clear();
                T3.Clear();
                T5.Text = "";
                group2.Header = R1.Content.ToString();
                T2.Text = "+";

                B1.Click += delegate
                {
                    try
                    {
                        var x = double.Parse(T1.Text);
                        var y = double.Parse(T3.Text);
                        sum = x + y;
                        T5.Text = sum.ToString();
                    }
                    catch
                    {
                        T5.Text = "?";
                    }
                };
            };
            R2.Click += delegate
            {
                T1.Clear();
                T3.Clear();
                T5.Text = "";
                group2.Header =R2.Content.ToString();
                T2.Text = "-";

                B1.Click += delegate
                {
                    try
                    {
                        var x = double.Parse(T1.Text);
                        var y = double.Parse(T3.Text);
                        sum = x - y;
                        T5.Text = sum.ToString();
                    }
                    catch
                    {
                        T5.Text = "?";
                    }
                };
            };
            R3.Click += delegate
            {
                T1.Clear();
                T3.Clear();
                T5.Text = "";
                group2.Header = R3.Content.ToString();
                T2.Text = "*";

                B1.Click += delegate
                {
                    try
                    {
                        var x = double.Parse(T1.Text);
                        var y = double.Parse(T3.Text);
                        sum = x * y;
                        T5.Text = sum.ToString();
                    }
                    catch
                    {
                        T5.Text = "?";
                    }
                };
            };
            R4.Click += delegate
            {
                T1.Clear();
                T3.Clear();
                T5.Text = "";
                group2.Header = R4.Content.ToString();
                T2.Text = "/";

                B1.Click += delegate
                {
                    try
                    {
                        var x = double.Parse(T1.Text);
                        var y = double.Parse(T3.Text);
                        sum = x / y;
                        T5.Text = sum.ToString();
                    }
                    catch
                    {
                        T5.Text = "?";
                    }
                };
            };
            R5.Click += delegate
            {
                T1.Clear();
                T3.Clear();
                T5.Text = "";
                group2.Header = R5.Content.ToString();
                T2.Text = "%";

                B1.Click += delegate
                {
                    try
                    {
                        var x = double.Parse(T1.Text);
                        var y = double.Parse(T3.Text);
                        sum = x % y;
                        T5.Text = sum.ToString();
                    }
                    catch
                    {
                        T5.Text = "?";
                    }
                };
            };
        }

        //    private void Button_Click(object sender, RoutedEventArgs e)
        //    {
        //        MessageBox.Show(string.Format("第一个数:{0}", T1.Text));
        //        MessageBox.Show(string.Format("第二个数:{0}", T3.Text));

        //    }

        //    private void CheckBox_Checked(object sender, RoutedEventArgs e)
        //    {

        //        if (C1.IsChecked == true)
        //        {
        //            i = 1;
        //            T2.Text = "+ ";
        //            T1.Clear();
        //            T3.Clear();
        //            group2.Header = C1.Content;
        //            T5.Text = "";

        //        }
        //        if (C1.IsChecked == false)
        //        {
        //            T2.Text = "";
        //        }

        //    }
        //    private void C2_Checked(object sender, RoutedEventArgs e)
        //    {
        //        if (C2.IsChecked == true)
        //        {
        //            i = 2;
        //            T2.Text=" -";
        //            T1.Clear();
        //            T3.Clear();
        //            group2.Header = C2.Content;
        //            T5.Text = "";
        //        }
        //        else
        //        {
        //            T2.Text = "";
        //        }
        //    }
        //    private void C3_Checked(object sender, RoutedEventArgs e)
        //    {
        //        if (C3.IsChecked == true)
        //        {
        //            i = 3;
        //            T2.Text = " *";
        //            T1.Clear();
        //            T3.Clear();
        //            group2.Header = C3.Content;
        //            T5.Text = "";
        //        }
        //    }
        //    private void C4_Checked(object sender, RoutedEventArgs e)
        //    {
        //        if (C4.IsChecked == true)
        //        {
        //            i = 4;
        //            T2.Text = " /";
        //            T1.Clear();
        //            T3.Clear();
        //            group2.Header = C4.Content;
        //            T5.Text = "";
        //        }
        //    }
        //    private void C5_Checked(object sender, RoutedEventArgs e)
        //    {
        //        if (C5.IsChecked == true)
        //        {
        //            i = 5;
        //            T2.Text = "%";
        //            T1.Clear();
        //            T3.Clear();
        //            group2.Header = C5.Content;
        //            T5.Text = "";
        //        }
        //    }


        //    private void T1_TextChanged(object sender, TextChangedEventArgs e)
        //    {

        //    }

        //    private void Button_Click_1(object sender, RoutedEventArgs e)
        //    {

        //        int x1 = int.Parse(T1.Text);
        //        int x2 = int.Parse(T3.Text);
        //        switch (i)
        //        {
        //            case 1: sum = x1 + x2; break;
        //            case 2: sum = x1 - x2; break;
        //            case 3: sum = x1 * x2; break;
        //            case 4: sum = x1 / x2; break;
        //            case 5: sum = x1 % x2; break;
        //        }

        //        string s = Convert.ToString(sum);
        //        T5.Text = s;
        //    }

    }
}
