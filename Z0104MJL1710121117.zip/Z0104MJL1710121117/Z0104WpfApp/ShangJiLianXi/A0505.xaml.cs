﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Z0104WpfApp.ShangJiLianXi
{
    /// <summary>
    /// A0505.xaml 的交互逻辑
    /// </summary>
    public partial class A0505 : Page
    {
        public A0505()
        {
            InitializeComponent();
        }
        private void textBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (textbox4 == null || textbox1 == null || textbox2 == null || textbox3 == null) return;
            byte A, R, G, B;
            if (byte.TryParse(textbox4.Text, out A) == false
                || byte.TryParse(textbox1.Text, out R) == false
                || byte.TryParse(textbox2.Text, out G) == false
                || byte.TryParse(textbox3.Text, out B) == false)
            {
                MessageBox.Show("输入有错，请修改！");
                return;
            }
            Color c = Color.FromArgb(A, R, G, B);
            text1.Background =new SolidColorBrush(c);
        }
    }
}
