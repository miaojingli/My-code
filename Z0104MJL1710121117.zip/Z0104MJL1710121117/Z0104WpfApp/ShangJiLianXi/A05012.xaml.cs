﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Z0104WpfApp.ShangJiLianXi
{
    /// <summary>
    /// A05012.xaml 的交互逻辑
    /// </summary>
    public partial class A05012 : Window
    {
        public A05012()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            text1.Text = "张三";
            text2.Text = "19岁";
            text3.Text = "喜欢打篮球";
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            var q = text1.Text + text2.Text + text3.Text;
            MessageBox.Show(q);

        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            Window w = new Window();
            Label label1 = new Label
            {
                Content = "Hello，" + text1.Text,
                FontSize = 30,
                HorizontalAlignment = System.Windows.HorizontalAlignment.Left,
                VerticalAlignment = System.Windows.VerticalAlignment.Top
            };
            Label label2 = new Label
            {
                Content =text2.Text,
                FontSize = 30,
                HorizontalAlignment = System.Windows.HorizontalAlignment.Center,
                VerticalAlignment = System.Windows.VerticalAlignment.Center
            }; Label label3 = new Label
            {
                Content =text3.Text,
                FontSize = 30,
                HorizontalAlignment = System.Windows.HorizontalAlignment.Right,
                VerticalAlignment = System.Windows.VerticalAlignment.Bottom
            };
            w.Content = label1;
            w.ShowDialog();
        }
    }
}
